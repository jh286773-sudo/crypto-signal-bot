# AURUM X by JAVAD 0.2.4

The user-selected futures exchange is the only source for the analysis cycle. Supported sources: Toobit, Binance Futures, Bybit, OKX, Bitget, Gate.io, CoinEx, MEXC Futures, BingX, KuCoin Futures and Phemex. The analysis timeframes are 5m, 15m and 30m.

The foreground service owns the analysis worker and selected-exchange WebSocket. Historical OHLCV candles are fetched from the selected exchange REST API; the latest valid live WebSocket candle is merged into the matching timeframe before signal calculation. A periodic REST safety refresh recovers history and covers temporary socket interruptions.

KuCoin Futures performs public-token bootstrap before opening its futures WebSocket. BingX binary GZIP frames are decompressed before parsing. MEXC and KuCoin heartbeat messages are answered. Phemex uses the documented `kline_p` public channel.

Build requirements: JDK 17+, Android SDK 35, Gradle 8.9 and internet access to resolve Android/OkHttp dependencies. The Gradle wrapper JAR is not included. Live exchange connectivity and APK installation must be verified in an online Android Studio/CI environment.
