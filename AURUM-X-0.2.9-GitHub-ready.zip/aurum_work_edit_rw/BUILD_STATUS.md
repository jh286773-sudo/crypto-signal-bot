# AURUM X 0.2.9 build status

## Completed source checks
- SignalEngine.kt and LiveCandleCache.kt compile independently with kotlinc.
- Python reference-engine test suite: 6 tests passed.
- WebSocket heartbeat/disconnect lifecycle source checks passed.
- Source archive integrity checked after packaging.
- GitHub Actions workflow added for Java 17, Android SDK 35, Gradle 8.9, reference tests, APK build, and artifact upload.
- Workflow supports either an extracted Android project or a source ZIP uploaded to the repository root.

## Not yet verified
- Full Android app compilation in GitHub Actions (has not been run from the user's repository).
- Runtime tests on an Android device/emulator.
- Live Toobit REST/WebSocket integration under real network conditions.

This package is source code plus a cloud-build workflow, not an installable APK. Do not treat independent source tests as proof of a complete Android build.
