package com.example.toobitsignals

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.GZIPInputStream

/** Public, unauthenticated perpetual-futures candle streams for the selected venue. */
internal class ExchangeWebSocketFeed(
    private val exchange: String,
    private val symbols: List<String>,
    private val onCandle: (String, String, LiveCandle) -> Unit,
    private val onState: (String) -> Unit,
    private val onDisconnected: () -> Unit
) {
    companion object { private val intervals = listOf("5m", "15m", "30m") }

    private val client = OkHttpClient.Builder()
        .pingInterval(18, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    @Volatile private var socket: WebSocket? = null
    @Volatile private var closed = false
    private val heartbeat: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var heartbeatTask: ScheduledFuture<*>? = null

    private fun stopHeartbeat() {
        heartbeatTask?.cancel(false)
        heartbeatTask = null
    }

    fun connect() {
        if (closed || symbols.isEmpty()) return
        if (exchange == "KuCoin Futures") {
            Thread({ connectKuCoinWithPublicToken() }, "aurum-kucoin-token").start()
            return
        }
        val url = when (exchange) {
            "Binance Futures" -> {
                val streams = symbols.flatMap { s -> intervals.map { "${s.lowercase()}@kline_$it" } }.joinToString("/")
                "wss://fstream.binance.com/market/stream?streams=$streams"
            }
            "Bybit" -> "wss://stream.bybit.com/v5/public/linear"
            "OKX" -> "wss://ws.okx.com:8443/ws/v5/public"
            "Bitget" -> "wss://ws.bitget.com/v2/ws/public"
            "Gate.io" -> "wss://fx-ws.gateio.ws/v4/ws/usdt"
            "CoinEx" -> "wss://perpetual.coinex.com/"
            "MEXC Futures" -> "wss://contract.mexc.com/edge"
            "Phemex" -> "wss://ws.phemex.com"
            "BingX" -> "wss://open-api-swap.bingx.com/swap-market"
            "Toobit" -> "wss://stream.toobit.com/quote/ws/v1"
            else -> { onState("WebSocket برای $exchange پشتیبانی نشده است."); return }
        }
        openSocket(url)
    }

    private fun openSocket(url: String) {
        if (closed) return
        socket = client.newWebSocket(Request.Builder().url(url).build(), listener())
    }

    /** KuCoin Futures requires a fresh public bullet token before its public WS can connect. */
    private fun connectKuCoinWithPublicToken() {
        try {
            val request = Request.Builder().url("https://api-futures.kucoin.com/api/v1/bullet-public")
                .post(okhttp3.RequestBody.create(null, ByteArray(0))).build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) throw IllegalStateException("KuCoin token HTTP ${response.code}")
                val root = JSONObject(body)
                if (root.optString("code") != "200000") throw IllegalStateException("KuCoin token: ${root.optString("msg", "خطای دریافت توکن")}")
                val data = root.getJSONObject("data")
                val token = data.getString("token")
                val servers = data.getJSONArray("instanceServers")
                if (servers.length() == 0) throw IllegalStateException("KuCoin سرور WebSocket برنگرداند")
                val server = servers.getJSONObject(0)
                val endpoint = server.getString("endpoint").trimEnd('/')
                val connectId = UUID.randomUUID().toString().replace("-", "")
                val wsUrl = endpoint.toHttpUrl().newBuilder()
                    .addQueryParameter("token", token)
                    .addQueryParameter("connectId", connectId)
                    .build().toString()
                if (!closed) openSocket(wsUrl)
            }
        } catch (e: Exception) {
            onState("KuCoin Futures: دریافت توکن/اتصال ناموفق: ${e.message ?: "خطای شبکه"}")
            if (!closed) onDisconnected()
        }
    }

    private fun listener() : WebSocketListener {
        val disconnectNotified = AtomicBoolean(false)
        return object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            onState("اتصال زنده WebSocket برقرار شد: $exchange")
            subscribe(webSocket)
            if (exchange == "Toobit") {
                stopHeartbeat()
                heartbeatTask = heartbeat.scheduleAtFixedRate({
                    if (!closed && socket === webSocket) {
                        val sent = webSocket.send(JSONObject().put("ping", System.currentTimeMillis()).toString())
                        if (!sent) stopHeartbeat()
                    }
                }, 90, 90, TimeUnit.SECONDS)
            }
        }
        override fun onMessage(webSocket: WebSocket, text: String) {
            if (exchange == "KuCoin Futures" && runCatching { JSONObject(text).optString("type") }.getOrNull() == "ping") {
                val id = runCatching { JSONObject(text).optString("id", System.currentTimeMillis().toString()) }.getOrDefault(System.currentTimeMillis().toString())
                webSocket.send(JSONObject().put("id", id).put("type", "pong").toString())
                return
            }
            if (exchange == "MEXC Futures" && runCatching { JSONObject(text).optString("method") }.getOrNull() == "ping") {
                webSocket.send(JSONObject().put("method", "pong").toString()); return
            }
            if (exchange == "BingX" && text.equals("Ping", true)) { webSocket.send("Pong"); return }
            parseAndPublish(text)
        }
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            if (exchange == "BingX") {
                try {
                    val decoded = GZIPInputStream(ByteArrayInputStream(bytes.toByteArray())).bufferedReader().use { it.readText() }
                    if (decoded.equals("Ping", true)) webSocket.send("Pong") else parseAndPublish(decoded)
                } catch (e: Exception) { onState("BingX: خطا در بازکردن پیام فشرده بازار: ${e.message}") }
            }
        }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            stopHeartbeat()
            onState("WebSocket $exchange قطع شد: ${t.message ?: "خطای شبکه"}")
            if (!closed && disconnectNotified.compareAndSet(false, true)) onDisconnected()
        }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            stopHeartbeat()
            if (!closed && disconnectNotified.compareAndSet(false, true)) onDisconnected()
        }
    }
    }

    private fun subscribe(ws: WebSocket) {
        when (exchange) {
            "Bybit" -> {
                val args = JSONArray()
                symbols.forEach { s -> intervals.forEach { tf -> args.put("kline.${tf.removeSuffix("m")}.$s") } }
                ws.send(JSONObject().put("op", "subscribe").put("args", args).toString())
            }
            "OKX" -> {
                val args = JSONArray()
                symbols.forEach { s -> intervals.forEach { tf -> args.put(JSONObject().put("channel", "candle$tf").put("instId", "${s.removeSuffix("USDT")}-USDT-SWAP")) } }
                ws.send(JSONObject().put("op", "subscribe").put("args", args).toString())
            }
            "Bitget" -> {
                val args = JSONArray()
                symbols.forEach { s -> intervals.forEach { tf -> args.put(JSONObject().put("instType", "USDT-FUTURES").put("channel", "candle$tf").put("instId", s)) } }
                ws.send(JSONObject().put("op", "subscribe").put("args", args).toString())
            }
            "Gate.io" -> symbols.forEach { s -> intervals.forEach { tf ->
                ws.send(JSONObject().put("time", System.currentTimeMillis() / 1000)
                    .put("channel", "futures.candlesticks").put("event", "subscribe")
                    .put("payload", JSONArray().put(tf).put("${s.removeSuffix("USDT")}_USDT")).toString())
            } }
            "CoinEx" -> symbols.forEach { s -> intervals.forEach { tf ->
                val period = when (tf) { "5m" -> 300; "15m" -> 900; else -> 1800 }
                ws.send(JSONObject().put("method", "kline.subscribe").put("params", JSONArray().put(s).put(period)).put("id", UUID.randomUUID().toString()).toString())
            } }
            "Toobit" -> symbols.forEach { s -> intervals.forEach { tf ->
                ws.send(JSONObject().put("symbol", s).put("topic", "kline_$tf").put("event", "sub")
                    .put("params", JSONObject().put("limit", "200").put("binary", "false")).toString())
            } }
            "MEXC Futures" -> symbols.forEach { s -> intervals.forEach { tf ->
                val interval = mexcInterval(tf)
                ws.send(JSONObject().put("method", "sub.kline").put("param", JSONObject().put("symbol", mexcSymbol(s)).put("interval", interval)).toString())
            } }
            "Phemex" -> symbols.forEach { s -> intervals.forEach { tf ->
                ws.send(JSONObject().put("id", System.nanoTime()).put("method", "kline_p.subscribe")
                    .put("params", JSONArray().put(s).put(intervalSeconds(tf))).toString())
            } }
            "BingX" -> symbols.forEach { s -> intervals.forEach { tf ->
                ws.send(JSONObject().put("id", UUID.randomUUID().toString()).put("reqType", "sub")
                    .put("dataType", "${s.removeSuffix("USDT")}-USDT@kline_$tf").toString())
            } }
            "KuCoin Futures" -> symbols.forEach { s -> intervals.forEach { tf ->
                val topic = "/contractMarket/limitCandle:${kucoinSymbol(s)}_${kucoinInterval(tf)}"
                ws.send(JSONObject().put("id", System.currentTimeMillis()).put("type", "subscribe")
                    .put("topic", topic).put("privateChannel", false).put("response", true).toString())
            } }
            // Binance uses a combined-stream URL; no subscribe frame is needed.
        }
    }

    private fun parseAndPublish(raw: String) {
        if (raw.isBlank()) return
        try {
            val root = JSONObject(raw)
            when (exchange) {
                "Toobit" -> {
                    val topic = root.optString("topic")
                    val tf = when {
                        topic.endsWith("5m") -> "5m"
                        topic.endsWith("15m") -> "15m"
                        topic.endsWith("30m") -> "30m"
                        else -> return
                    }
                    val outerSymbol = root.optString("symbol")
                    val data = root.optJSONArray("data")
                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val k = data.optJSONObject(i) ?: continue
                            publishToobitCandle(k, outerSymbol, tf)
                        }
                    } else {
                        // Some stream variants wrap a single candle object instead of an array.
                        val single = root.optJSONObject("data") ?: return
                        publishToobitCandle(single, outerSymbol, tf)
                    }
                }
                "MEXC Futures" -> {
                    val d = root.optJSONObject("data") ?: return
                    val symbol = normalizeMexcSymbol(d.optString("symbol", root.optString("symbol")))
                    val tf = fromMexcInterval(d.optString("interval"))
                    publish(symbol, tf, LiveCandle(d.optLong("t") * 1000L, d.optString("o").toDouble(), d.optString("h").toDouble(), d.optString("l").toDouble(), d.optString("c").toDouble(), d.optString("q", "0").toDouble()))
                }
                "BingX" -> {
                    val data = root.optJSONObject("data") ?: return
                    val k = data.optJSONObject("K") ?: data.optJSONObject("k") ?: data
                    val symbol = normalizeDashSymbol(data.optString("s", root.optString("dataType").substringBefore('@')))
                    val tf = fromBingXTopic(root.optString("dataType"))
                    val time = k.optLong("t", k.optLong("time"))
                    publish(symbol, tf, LiveCandle(time, k.optString("o").toDouble(), k.optString("h").toDouble(), k.optString("l").toDouble(), k.optString("c").toDouble(), k.optString("v", "0").toDouble()))
                }
                "KuCoin Futures" -> {
                    val d = root.optJSONObject("data") ?: return
                    val topic = root.optString("topic")
                    val tf = topic.substringAfterLast('_').let { fromKucoinInterval(it) }
                    val symbol = d.optString("symbol", topic.substringAfter(':').substringBefore('_'))
                    val a = d.optJSONArray("candles") ?: return
                    if (a.length() >= 6) publish(normalizeKucoinSymbol(symbol), tf,
                        LiveCandle(a.optString(0).toLong() * 1000L, a.optString(1).toDouble(), a.optString(3).toDouble(), a.optString(4).toDouble(), a.optString(2).toDouble(), a.optString(5).toDouble()))
                }
                "Phemex" -> {
                    val symbol = root.optString("symbol")
                    val rows = root.optJSONArray("kline") ?: return
                    for (i in 0 until rows.length()) {
                        val a = rows.optJSONArray(i) ?: continue
                        if (a.length() < 8) continue
                        val sec = a.optString(0).toLongOrNull() ?: continue
                        val tf = when (a.optInt(1)) { 300 -> "5m"; 900 -> "15m"; 1800 -> "30m"; else -> continue }
                        publish(symbol, tf, LiveCandle(toEpochMillis(sec),
                            a.optString(3).toDouble(), a.optString(4).toDouble(), a.optString(5).toDouble(), a.optString(6).toDouble(), a.optString(7).toDouble()))
                    }
                }
                else -> parseLegacyExchange(root)
            }
        } catch (_: Exception) { /* Ignore acknowledgements, heartbeats and malformed frames. */ }
    }

    private fun publishToobitCandle(k: JSONObject, outerSymbol: String, tf: String) {
        val symbol = k.optString("s", outerSymbol).ifBlank { outerSymbol }
        val rawTime = k.optString("t").toLongOrNull() ?: k.optLong("t")
        val timeMs = toEpochMillis(rawTime)
        val open = k.optString("o").toDoubleOrNull() ?: return
        val high = k.optString("h").toDoubleOrNull() ?: return
        val low = k.optString("l").toDoubleOrNull() ?: return
        val close = k.optString("c").toDoubleOrNull() ?: return
        val volume = k.optString("v", "0").toDoubleOrNull() ?: 0.0
        publish(symbol, tf, LiveCandle(timeMs, open, high, low, close, volume))
    }

    private fun parseLegacyExchange(root: JSONObject) {
        when (exchange) {
            "Binance Futures" -> {
                val d = root.optJSONObject("data") ?: root
                val k = d.optJSONObject("k") ?: return
                publish(k.optString("s"), k.optString("i"), LiveCandle(k.optLong("t"), k.optString("o").toDouble(), k.optString("h").toDouble(), k.optString("l").toDouble(), k.optString("c").toDouble(), k.optString("v").toDouble()))
            }
            "Bybit" -> {
                val topic = root.optString("topic"); val symbol = topic.substringAfterLast('.')
                val tf = topic.substringAfter("kline.").substringBefore('.') + "m"
                val d = root.optJSONArray("data")?.optJSONObject(0) ?: return
                publish(symbol, tf, LiveCandle(d.optLong("start"), d.optString("open").toDouble(), d.optString("high").toDouble(), d.optString("low").toDouble(), d.optString("close").toDouble(), d.optString("volume").toDouble()))
            }
            "OKX", "Bitget" -> {
                val arg = root.optJSONObject("arg") ?: return
                val symbol = if (exchange == "OKX") arg.optString("instId").replace("-USDT-SWAP", "USDT") else arg.optString("instId")
                val tf = arg.optString("channel").removePrefix("candle")
                val a = root.optJSONArray("data")?.optJSONArray(0) ?: return
                publish(symbol, tf, LiveCandle(a.optString(0).toLong(), a.optString(1).toDouble(), a.optString(2).toDouble(), a.optString(3).toDouble(), a.optString(4).toDouble(), a.optString(5).toDouble()))
            }
            "Gate.io" -> {
                val a = root.optJSONArray("result")?.optJSONObject(0) ?: return
                val tf = root.optJSONArray("result")?.let { root.optString("channel").substringAfter('_').substringBefore('_') } ?: return
                val symbol = a.optString("n").ifBlank { a.optString("contract").replace("_", "") }
                publish(symbol, tf, LiveCandle(a.optLong("t") * 1000L, a.optString("o").toDouble(), a.optString("h").toDouble(), a.optString("l").toDouble(), a.optString("c").toDouble(), a.optString("v").toDouble()))
            }
            "CoinEx" -> {
                val p = root.optJSONArray("params") ?: return
                val symbol = p.optString(0); val rows = p.optJSONArray(1) ?: return
                val period = p.optInt(2)
                val tf = when (period) { 300 -> "5m"; 900 -> "15m"; 1800 -> "30m"; else -> return }
                val a = rows.optJSONArray(0) ?: rows
                publish(symbol, tf, LiveCandle(a.optString(0).toLong() * 1000L, a.optString(1).toDouble(), a.optString(3).toDouble(), a.optString(4).toDouble(), a.optString(2).toDouble(), a.optString(5).toDouble()))
            }
        }
    }

    private fun publish(symbolRaw: String, tf: String, candle: LiveCandle) {
        val symbol = symbolRaw.trim().uppercase()
        if (symbol !in symbols || tf !in intervals) return
        val timeMs = if (candle.time >= 100_000_000_000L) candle.time else toEpochMillis(candle.time)
        onCandle(symbol, tf, candle.copy(time = timeMs))
    }
    private fun toEpochMillis(value: Long): Long = when {
        value >= 100_000_000_000_000_000L -> value / 1_000_000L // nanoseconds
        value >= 100_000_000_000_000L -> value / 1_000L // microseconds
        value >= 100_000_000_000L -> value // milliseconds
        else -> value * 1000L // seconds
    }
    private fun intervalSeconds(tf: String) = when (tf) { "5m" -> 300; "15m" -> 900; else -> 1800 }
    private fun mexcInterval(tf: String) = when (tf) { "5m" -> "Min5"; "15m" -> "Min15"; else -> "Min30" }
    private fun fromMexcInterval(v: String) = when (v) { "Min5" -> "5m"; "Min15" -> "15m"; "Min30" -> "30m"; else -> "" }
    private fun mexcSymbol(s: String) = "${s.removeSuffix("USDT")}_USDT"
    private fun normalizeMexcSymbol(s: String) = s.replace("_", "").uppercase()
    private fun kucoinSymbol(s: String) = if (s == "BTCUSDT") "XBTUSDTM" else "${s.removeSuffix("USDT")}USDTM"
    private fun normalizeKucoinSymbol(s: String) = if (s == "XBTUSDTM") "BTCUSDT" else s.removeSuffix("M")
    private fun kucoinInterval(tf: String) = when (tf) { "5m" -> "5min"; "15m" -> "15min"; else -> "30min" }
    private fun fromKucoinInterval(v: String) = when (v) { "5min" -> "5m"; "15min" -> "15m"; "30min" -> "30m"; else -> "" }
    private fun fromBingXTopic(v: String) = when { "kline_5m" in v -> "5m"; "kline_15m" in v -> "15m"; "kline_30m" in v -> "30m"; else -> "" }
    private fun normalizeDashSymbol(s: String) = s.substringBefore('@').replace("-", "").uppercase()

    fun close() {
        closed = true
        stopHeartbeat()
        heartbeat.shutdownNow()
        socket?.close(1000, "service stopped")
        socket = null
        client.dispatcher.executorService.shutdown()
        client.connectionPool.evictAll()
    }
}
