package com.example.toobitsignals

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Exchange-aware, read-only futures market data adapter. */
internal class MarketDataAnalyzer {
    companion object {
        val SUPPORTED_EXCHANGES = setOf("Toobit")
    }

    private data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)

    private fun getJson(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 12_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "AURUM-X/1.1")
            if (url.contains("open-api.bingx.com")) setRequestProperty("X-SOURCE-KEY", "BX-AI-SKILL")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code: ${body.take(120)}")
            return body
        } finally { connection.disconnect() }
    }

    private fun number(value: String?, fallback: Double = 0.0): Double = value?.toDoubleOrNull()?.takeIf { it.isFinite() } ?: fallback
    /** Exchange candle timestamps may arrive as seconds, milliseconds or nanoseconds. Cache uses ms. */
    private fun timestamp(value: String?): Long {
        val raw = value?.toLongOrNull()?.takeIf { it > 0 } ?: return 0L
        return when {
            raw >= 100_000_000_000_000_000L -> raw / 1_000_000L // nanoseconds
            raw >= 100_000_000_000_000L -> raw / 1_000L // microseconds
            raw >= 100_000_000_000L -> raw // milliseconds
            else -> raw * 1_000L // seconds
        }
    }

    private fun candles(exchange: String, symbol: String, timeframe: String): List<Candle> {
        require(exchange in SUPPORTED_EXCHANGES) { "صرافی انتخاب‌شده پشتیبانی نمی‌شود: $exchange" }
        require(timeframe in setOf("5m", "15m", "30m")) { "تایم‌فریم نامعتبر: $timeframe" }
        val market = symbol.removeSuffix("USDT")
        val coinexPeriod = when (timeframe) { "5m" -> "5min"; "15m" -> "15min"; else -> "30min" }
        val mexcInterval = when (timeframe) { "5m" -> "Min5"; "15m" -> "Min15"; else -> "Min30" }
        val kucoinSymbol = if (symbol == "BTCUSDT") "XBTUSDTM" else "${market}USDTM"
        val kucoinGranularity = when (timeframe) { "5m" -> 300; "15m" -> 900; else -> 1800 }
        val nowSeconds = System.currentTimeMillis() / 1000L
        val url = when (exchange) {
            "Binance Futures" -> "https://fapi.binance.com/fapi/v1/klines?symbol=$symbol&interval=$timeframe&limit=120"
            "Bybit" -> "https://api.bybit.com/v5/market/kline?category=linear&symbol=$symbol&interval=${timeframe.removeSuffix("m")}&limit=120"
            "OKX" -> "https://www.okx.com/api/v5/market/candles?instId=$market-USDT-SWAP&bar=$timeframe&limit=120"
            "Bitget" -> "https://api.bitget.com/api/v2/mix/market/candles?symbol=$symbol&productType=USDT-FUTURES&granularity=$timeframe&limit=120"
            "Gate.io" -> "https://api.gateio.ws/api/v4/futures/usdt/candlesticks?contract=${market}_USDT&interval=$timeframe&limit=120"
            "CoinEx" -> "https://api.coinex.com/v2/futures/kline?market=$symbol&period=$coinexPeriod&limit=120"
            "MEXC Futures" -> "https://contract.mexc.com/api/v1/contract/kline/${market}_USDT?interval=$mexcInterval&start=${nowSeconds - 120L * kucoinGranularity}&end=$nowSeconds"
            "BingX" -> "https://open-api.bingx.com/openApi/swap/v3/quote/klines?symbol=$market-USDT&interval=$timeframe&limit=120"
            "KuCoin Futures" -> "https://api-futures.kucoin.com/api/v1/kline/query?symbol=$kucoinSymbol&granularity=$kucoinGranularity&from=${(nowSeconds - 120L * kucoinGranularity) * 1000L}&to=${nowSeconds * 1000L}"
            "Phemex" -> "https://api.phemex.com/exchange/public/md/v2/kline/last?symbol=$symbol&resolution=$kucoinGranularity&limit=120"
            "Toobit" -> {
                val windowMs = when (timeframe) { "5m" -> 5L; "15m" -> 15L; else -> 30L } * 60_000L * 120L
                val end = System.currentTimeMillis()
                "https://api.toobit.com/quote/v1/klines?symbol=$symbol&interval=$timeframe&limit=120&startTime=${end - windowMs}&endTime=$end"
            }
            else -> throw IllegalArgumentException("هیچ مسیر جایگزینی برای صرافی ناشناخته مجاز نیست: $exchange")
        }
        val raw = getJson(url)
        val root = try { JSONObject(raw) } catch (_: Exception) { null }
        if (root != null) {
            val code = root.optString("retCode", root.optString("code", "0"))
            if (code != "0" && code != "00000" && code != "200" && code != "200000" && code != "") {
                throw IllegalStateException("$exchange API: ${root.optString("retMsg", root.optString("message", code))}")
            }
        }
        val mexcData = root?.optJSONObject("data")
        val rows = when (exchange) {
            "Bybit" -> root?.optJSONObject("result")?.optJSONArray("list")
            "OKX", "Bitget" -> root?.optJSONArray("data")
            "BingX" -> root?.optJSONArray("data")
            "CoinEx" -> root?.optJSONObject("data")?.optJSONArray("data") ?: root?.optJSONArray("data")
            "KuCoin Futures" -> root?.optJSONArray("data")
            "Phemex" -> root?.optJSONObject("data")?.optJSONArray("rows") ?: root?.optJSONObject("result")?.optJSONArray("rows")
            else -> try { JSONArray(raw) } catch (_: Exception) { null }
        }
        if (exchange == "MEXC Futures") {
            val times = mexcData?.optJSONArray("time")
            val opens = mexcData?.optJSONArray("open")
            val highs = mexcData?.optJSONArray("high")
            val lows = mexcData?.optJSONArray("low")
            val closes = mexcData?.optJSONArray("close")
            val volumes = mexcData?.optJSONArray("vol")
            if (times == null || opens == null || highs == null || lows == null || closes == null) {
                throw IllegalStateException("ساختار پاسخ MEXC قابل شناسایی نیست")
            }
            val parsedMexc = ArrayList<Candle>(times.length())
            for (i in 0 until times.length()) {
                val c = Candle(times.optLong(i) * 1000L, opens.optDouble(i), highs.optDouble(i), lows.optDouble(i), closes.optDouble(i), volumes?.optDouble(i) ?: 0.0)
                if (c.time > 0 && c.open > 0 && c.high >= maxOf(c.open, c.close) && c.low <= minOf(c.open, c.close)) parsedMexc.add(c)
            }
            val result = parsedMexc.distinctBy { it.time }.sortedBy { it.time }
            if (result.size < 60) throw IllegalStateException("MEXC / $symbol / $timeframe: فقط ${result.size} کندل معتبر")
            val merged = result.associateBy { it.time }.toMutableMap()
            LiveCandleCache.get(exchange, symbol, timeframe)?.let { live ->
                merged[live.time] = Candle(live.time, live.open, live.high, live.low, live.close, live.volume)
            }
            return merged.values.sortedBy { it.time }.takeLast(120)
        }
        val actualRows = rows ?: throw IllegalStateException("ساختار پاسخ $exchange قابل شناسایی نیست")

        val parsed = ArrayList<Candle>(actualRows.length())
        for (i in 0 until actualRows.length()) {
            try {
                val row = actualRows.opt(i)
                val candle = when {
                    row is JSONArray && exchange == "Phemex" -> {
                        // Phemex rows: [timestamp, interval, lastClose, open, high, low, close, volume, turnover].
                        val rawTime = timestamp(row.optString(0))
                        val timeMs = when {
                            rawTime >= 100_000_000_000_000_000L -> rawTime / 1_000_000L
                            rawTime >= 100_000_000_000L -> rawTime
                            else -> rawTime * 1000L
                        }
                        Candle(timeMs, number(row.optString(3)), number(row.optString(4)), number(row.optString(5)), number(row.optString(6)), number(row.optString(7)))
                    }
                    row is JSONArray && exchange == "KuCoin Futures" -> {
                        // KuCoin Futures rows: [time(ms), open, close, high, low, volume, turnover].
                        Candle(timestamp(row.optString(0)), number(row.optString(1)), number(row.optString(3)), number(row.optString(4)), number(row.optString(2)), number(row.optString(5)))
                    }
                    row is JSONObject && exchange == "BingX" -> {
                        // BingX swap kline objects: {time, open, high, low, close, volume}.
                        Candle(timestamp(row.optString("time")), number(row.optString("open")), number(row.optString("high")), number(row.optString("low")), number(row.optString("close")), number(row.optString("volume")))
                    }
                    row is JSONArray && exchange == "Gate.io" -> {
                        // Gate.io returns [timestamp, volume, close, high, low, ...], no open.
                        val close = number(row.optString(2))
                        val reportedOpen = if (row.length() > 5) number(row.optString(5), close) else close
                        // Gate.io REST may omit open in legacy payloads; prefer reported open when present.
                        val open = reportedOpen.takeIf { it > 0 && it in number(row.optString(4))..number(row.optString(3)) } ?: close
                        Candle(timestamp(row.optString(0)), open, number(row.optString(3)), number(row.optString(4)), close, number(row.optString(1)))
                    }
                    row is JSONArray -> {
                        // Binance, Bybit, OKX, Bitget, BingX and Toobit use [time, open, high, low, close, volume, ...].
                        val timeRaw = row.optString(0)
                        val time = timestamp(timeRaw)
                        Candle(time, number(row.optString(1)), number(row.optString(2)), number(row.optString(3)), number(row.optString(4)), number(row.optString(5)))
                    }
                    row is JSONObject && exchange == "CoinEx" -> {
                        val time = timestamp(row.optString("created_at", row.optString("timestamp", "0")))
                        Candle(time, number(row.optString("open")), number(row.optString("high")), number(row.optString("low")), number(row.optString("close")), number(row.optString("volume", row.optString("vol"))))
                    }
                    else -> continue
                }
                if (candle.time > 0 && candle.open > 0 && candle.high > 0 && candle.low > 0 && candle.close > 0 &&
                    candle.high >= candle.low && candle.high >= maxOf(candle.open, candle.close) &&
                    candle.low <= minOf(candle.open, candle.close)) parsed.add(candle)
            } catch (_: Exception) { /* Ignore malformed rows, but validate the final candle count. */ }
        }
        val sorted = parsed.distinctBy { it.time }.sortedBy { it.time }
        if (sorted.size < 60) throw IllegalStateException("$exchange / $symbol / $timeframe: فقط ${sorted.size} کندل معتبر؛ حداقل ۶۰ لازم است")
        // REST supplies deep history; the freshest in-progress candle is replaced by the
        // selected venue's live WebSocket candle when it is recent and valid.
        val merged = sorted.associateBy { it.time }.toMutableMap()
        LiveCandleCache.get(exchange, symbol, timeframe)?.let { live ->
            val newestRestTime = sorted.lastOrNull()?.time ?: 0L
            // Never let an old/out-of-order socket update replace newer REST history.
            if (live.time >= newestRestTime) {
                merged[live.time] = Candle(live.time, live.open, live.high, live.low, live.close, live.volume)
            }
        }
        return merged.values.sortedBy { it.time }.takeLast(120)
    }

    fun analyze(symbol: String, exchange: String): String {
        require(exchange in SUPPORTED_EXCHANGES) { "صرافی انتخاب‌شده معتبر نیست: $exchange" }
        val data = mapOf("5m" to candles(exchange, symbol, "5m"), "15m" to candles(exchange, symbol, "15m"), "30m" to candles(exchange, symbol, "30m"))
        val bars = data.mapValues { (_, values) -> values.map { SignalEngine.Bar(it.open, it.high, it.low, it.close, it.volume) } }
        val report = SignalEngine.analyze(bars)
        val price = String.format(Locale.US, "%.6f", data.getValue("5m").last().close)
        return "$symbol  ${report.signal}\nمنبع داده: $exchange | تایم‌فریم‌ها: 5m / 15m / 30m\nقیمت: $price | امتیاز ترکیبی: ${String.format(Locale.US, "%.2f", report.score)} | اطمینان مدل: ${String.format(Locale.US, "%.1f", report.confidence)}\n${report.details}\n${if (report.signal == "NO_SIGNAL") "شرایط ورود کامل نیست؛ هیچ سیگنالی ارسال نشد" else "تحلیل فقط خواندنی است؛ سفارش ثبت نمی‌شود"}"
    }
}
