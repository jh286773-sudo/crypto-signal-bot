package com.example.toobitsignals

import kotlin.math.*

object SignalEngine {

    data class Bar(
        val open: Double,
        val high: Double,
        val low: Double,
        val close: Double,
        val volume: Double
    )

    data class Report(
        val signal: String,
        val score: Double,
        val confidence: Double,
        val details: String,
        val entry: Double? = null,
        val sl: Double? = null,
        val tps: List<Double> = emptyList()
    )

    private const val MIN_BARS = 60
    private const val PERIOD = 14

    private fun validBars(c: List<Bar>): Boolean {
        if (c.size < MIN_BARS) return false
        return c.all {
            it.open.isFinite() && it.high.isFinite() && it.low.isFinite() &&
            it.close.isFinite() && it.volume.isFinite() &&
            it.open > 0 && it.close > 0 && it.low > 0 &&
            it.high >= it.low && it.high >= it.open && it.high >= it.close &&
            it.low <= it.open && it.low <= it.close && it.volume >= 0
        }
    }

    private fun ema(v: List<Double>, n: Int): Double? {
        if (v.size < n) return null
        val alpha = 2.0 / (n + 1)
        var result = v.take(n).average()
        for (x in v.drop(n)) result = alpha * x + (1 - alpha) * result
        return result
    }

    private fun sma(v: List<Double>, n: Int): Double? =
        if (v.size < n) null else v.takeLast(n).average()

    private fun rsi(v: List<Double>, n: Int = PERIOD): Double? {
        if (v.size < n + 1) return null
        val changes = (1 until v.size).map { v[it] - v[it - 1] }
        var gain = changes.take(n).sumOf { max(0.0, it) } / n
        var loss = changes.take(n).sumOf { max(0.0, -it) } / n
        for (x in changes.drop(n)) {
            gain = (gain * (n - 1) + max(0.0, x)) / n
            loss = (loss * (n - 1) + max(0.0, -x)) / n
        }
        if (gain == 0.0 && loss == 0.0) return 50.0
        if (loss == 0.0) return 100.0
        if (gain == 0.0) return 0.0
        return 100.0 - 100.0 / (1.0 + gain / loss)
    }

    private fun atr(c: List<Bar>, n: Int = PERIOD): Double? {
        if (c.size < n + 1) return null
        val tr = (1 until c.size).map {
            max(c[it].high - c[it].low,
                max(abs(c[it].high - c[it - 1].close), abs(c[it].low - c[it - 1].close)))
        }
        var value = tr.take(n).average()
        for (x in tr.drop(n)) value = (value * (n - 1) + x) / n
        return value.takeIf { it.isFinite() && it > 0 }
    }

    private fun adxVote(c: List<Bar>, n: Int = PERIOD): Double {
        if (c.size < 2 * n + 1) return 0.0
        val plus = mutableListOf<Double>()
        val minus = mutableListOf<Double>()
        val tr = mutableListOf<Double>()
        for (i in 1 until c.size) {
            val up = c[i].high - c[i - 1].high
            val down = c[i - 1].low - c[i].low
            plus.add(if (up > down && up > 0) up else 0.0)
            minus.add(if (down > up && down > 0) down else 0.0)
            tr.add(max(c[i].high - c[i].low,
                max(abs(c[i].high - c[i - 1].close), abs(c[i].low - c[i - 1].close))))
        }
        var p = plus.take(n).sum()
        var m = minus.take(n).sum()
        var t = tr.take(n).sum()
        val dx = mutableListOf<Double>()
        for (i in n until tr.size) {
            p = p - p / n + plus[i]
            m = m - m / n + minus[i]
            t = t - t / n + tr[i]
            if (t > 0) {
                val pd = 100 * p / t
                val md = 100 * m / t
                dx.add(if (pd + md > 0) 100 * abs(pd - md) / (pd + md) else 0.0)
            }
        }
        if (dx.size < n) return 0.0
        var adx = dx.take(n).average()
        for (x in dx.drop(n)) adx = (adx * (n - 1) + x) / n
        if (adx < 20) return 0.0
        return when { p > m -> 1.0; m > p -> -1.0; else -> 0.0 }
    }

    private fun stochVote(v: List<Double>, n: Int = PERIOD): Double {
        if (v.size < 2 * n + 1) return 0.0
        val values = (v.size - n..v.size).mapNotNull { end -> rsi(v.take(end), n) }
        if (values.size < n) return 0.0
        val window = values.takeLast(n)
        val low = window.minOrNull() ?: return 0.0
        val high = window.maxOrNull() ?: return 0.0
        if (high == low) return 0.0
        val k = 100 * (window.last() - low) / (high - low)
        return when { k > 55 -> 1.0; k < 45 -> -1.0; else -> 0.0 }
    }

    private fun cloudMid(c: List<Bar>, endExclusive: Int, period: Int): Double? {
        if (endExclusive < period) return null
        val window = c.subList(endExclusive - period, endExclusive)
        return (window.maxOf { it.high } + window.minOf { it.low }) / 2.0
    }

    private fun ichimokuVote(c: List<Bar>): Double {
        if (c.size < 78) return 0.0
        val cloudEnd = c.size - 26
        val tenkan = cloudMid(c, cloudEnd, 9) ?: return 0.0
        val kijun = cloudMid(c, cloudEnd, 26) ?: return 0.0
        val spanA = (tenkan + kijun) / 2.0
        val spanB = cloudMid(c, cloudEnd, 52) ?: return 0.0
        val price = c.last().close
        val fast = ema(c.map { it.close }, 9) ?: return 0.0
        val slow = ema(c.map { it.close }, 21) ?: return 0.0
        return when {
            price > max(spanA, spanB) && fast > slow -> 1.0
            price < min(spanA, spanB) && fast < slow -> -1.0
            else -> 0.0
        }
    }

    private fun score(c: List<Bar>): Pair<Double, Double> {
        require(validBars(c)) { "داده کندل ناقص یا نامعتبر است." }
        val v = c.map { it.close }
        val price = v.last()
        val e9 = ema(v, 9)!!
        val e21 = ema(v, 21)!!
        val e50 = ema(v, 50)!!
        val s20 = sma(v, 20)!!
        val s50 = sma(v, 50)!!
        val r = rsi(v)!!

        val macd = (ema(v, 12) ?: return 0.0 to 0.0) - (ema(v, 26) ?: return 0.0 to 0.0)
        val previous = v.dropLast(1)
        val previousMacd = (ema(previous, 12) ?: macd) - (ema(previous, 26) ?: macd)
        val macdVote = when {
            macd - previousMacd > 0 -> 1.0
            macd - previousMacd < 0 -> -1.0
            else -> 0.0
        }

        val mfiBars = c.takeLast(14)
        var positiveFlow = 0.0
        var negativeFlow = 0.0
        for (i in 1 until mfiBars.size) {
            val current = mfiBars[i]
            val previousBar = mfiBars[i - 1]
            val typical = (current.high + current.low + current.close) / 3.0
            val previousTypical = (previousBar.high + previousBar.low + previousBar.close) / 3.0
            val flow = typical * current.volume
            if (typical > previousTypical) positiveFlow += flow
            else if (typical < previousTypical) negativeFlow += flow
        }
        val mfi = when {
            positiveFlow == 0.0 && negativeFlow == 0.0 -> 50.0
            negativeFlow == 0.0 -> 100.0
            positiveFlow == 0.0 -> 0.0
            else -> 100.0 - 100.0 / (1.0 + positiveFlow / negativeFlow)
        }

        val volumeBars = c.takeLast(20)
        val volume = volumeBars.sumOf { it.volume }
        val vwap = if (volume > 0) volumeBars.sumOf {
            ((it.high + it.low + it.close) / 3.0) * it.volume
        } / volume else price
        val vwapVote = when { price > vwap -> 1.0; price < vwap -> -1.0; else -> 0.0 }

        val obv = (1 until c.size).sumOf {
            when {
                c[it].close > c[it - 1].close -> c[it].volume
                c[it].close < c[it - 1].close -> -c[it].volume
                else -> 0.0
            }
        }
        val obvVote = when { obv > 0 -> 1.0; obv < 0 -> -1.0; else -> 0.0 }
        val mfiVote = when { mfi > 50 -> 1.0; mfi < 50 -> -1.0; else -> 0.0 }

        val previousBars = c.takeLast(21).dropLast(1)
        val previousHigh = previousBars.maxOf { it.high }
        val previousLow = previousBars.minOf { it.low }
        val last = c.last()
        val structureVote = when {
            last.close > previousHigh || (last.low < previousLow && last.close > previousLow) -> 1.0
            last.close < previousLow || (last.high > previousHigh && last.close < previousHigh) -> -1.0
            else -> 0.0
        }
        val ichi = ichimokuVote(c)
        val trendVote = when { e9 > e21 && e21 > e50 -> 1.0; e9 < e21 && e21 < e50 -> -1.0; else -> 0.0 }
        val smaVote = when { price > s20 && s20 > s50 -> 1.0; price < s20 && s20 < s50 -> -1.0; else -> 0.0 }
        val rsiVote = when { r in 52.0..70.0 -> 1.0; r in 30.0..48.0 -> -1.0; else -> 0.0 }
        val bbMid = sma(v, 20)!!
        val volatilityVote = when { price > bbMid -> 1.0; price < bbMid -> -1.0; else -> 0.0 }

        val groups = linkedMapOf(
            "trend" to listOf(trendVote to 1.2, smaVote to 1.0, ichi to 1.2),
            "momentum" to listOf(rsiVote to 1.0, macdVote to 1.2, stochVote(v) to 1.0),
            "strength" to listOf(adxVote(c) to 1.2),
            "volume" to listOf(vwapVote to 1.0, obvVote to 1.0, mfiVote to 1.0),
            "volatility" to listOf(volatilityVote to 1.0),
            "structure" to listOf(structureVote to 1.3)
        )
        val weights = mapOf("trend" to 1.5, "momentum" to 1.3, "strength" to 1.1,
            "volume" to 1.0, "volatility" to 0.6, "structure" to 1.4)
        val familyScores = groups.mapValues { (_, items) ->
            items.sumOf { it.first * it.second } / items.sumOf { it.second }
        }
        val totalWeight = familyScores.keys.sumOf { weights[it]!! }
        val result = 100.0 * familyScores.entries.sumOf { it.value * weights[it.key]!! } / totalWeight
        return result.coerceIn(-100.0, 100.0) to (atr(c) ?: 0.0)
    }

    private fun noSignal(message: String, score: Double = 0.0) =
        Report("NO_SIGNAL", score, 0.0, message)

    fun analyze(data: Map<String, List<Bar>>): Report {
        val timeframes = listOf("5m", "15m", "30m")
        if (timeframes.any { !validBars(data[it] ?: emptyList()) }) {
            return noSignal("داده معتبر برای هر سه تایم‌فریم موجود نیست؛ سیگنالی صادر نشد.")
        }
        return try {
            val (s5, a5) = score(data["5m"]!!)
            val (s15, _) = score(data["15m"]!!)
            val (s30, _) = score(data["30m"]!!)
            val scores = listOf(s5, s15, s30)
            val combined = s5 * 0.25 + s15 * 0.35 + s30 * 0.40
            val allLong = scores.all { it >= 22.0 }
            val allShort = scores.all { it <= -22.0 }
            val side = when {
                allLong && combined >= 28.0 -> "LONG"
                allShort && combined <= -28.0 -> "SHORT"
                else -> "NO_SIGNAL"
            }
            if (side == "NO_SIGNAL") return noSignal(
                "تأیید هم‌جهتی هر سه تایم‌فریم انجام نشد؛ هیچ سیگنالی صادر نشد.", combined
            )

            val price = data["5m"]!!.last().close
            val risk = max(a5 * 1.5, price * 0.001)
            if (!risk.isFinite() || risk <= 0) return noSignal("محاسبه حد ضرر معتبر نیست.")
            val stopLoss: Double
            val targets: List<Double>
            if (side == "LONG") {
                stopLoss = price - risk
                targets = listOf(price + risk, price + risk * 2, price + risk * 3)
            } else {
                stopLoss = price + risk
                targets = listOf(price - risk, price - risk * 2, price - risk * 3)
            }
            val confidence = (abs(combined) * 0.75 + 24.0).coerceIn(0.0, 99.0)
            fun fmt(value: Double) = String.format(java.util.Locale.US, "%.6f", value)
            val details = buildString {
                append("سیگنال تأییدشده: $side\n")
                append("امتیاز ۵ دقیقه: ${fmt(s5)}\n")
                append("امتیاز ۱۵ دقیقه: ${fmt(s15)}\n")
                append("امتیاز ۳۰ دقیقه: ${fmt(s30)}\n")
                append("امتیاز ترکیبی: ${fmt(combined)}\n")
                append("ورود: ${fmt(price)}\n")
                append("حد ضرر: ${fmt(stopLoss)}\n")
                append("هدف اول: ${fmt(targets[0])}\n")
                append("هدف دوم: ${fmt(targets[1])}\n")
                append("هدف سوم: ${fmt(targets[2])}")
            }
            Report(side, combined, confidence, details, price, stopLoss, targets)
        } catch (e: Exception) {
            noSignal("خطا در تحلیل داده‌ها؛ هیچ سیگنالی صادر نشد.")
        }
    }
}
