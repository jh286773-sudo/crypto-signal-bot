package com.example.toobitsignals

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Callable
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Owns the WebSocket connection and analysis worker independently of the Activity lifecycle. */
class KeepAliveService : Service() {
    companion object {
        const val ACTION_STATUS = "com.example.toobitsignals.ANALYSIS_STATUS"
        const val EXTRA_STATUS = "status"
        const val EXTRA_RUNNING = "running"
        private const val NOTIFICATION_ID = 2401
        private const val CHANNEL_ID = "aurum_continuous_analysis"
        private const val SIGNAL_CHANNEL_ID = "aurum_confirmed_signals"
    }

    @Volatile private var running = false
    private var worker: ScheduledExecutorService = Executors.newScheduledThreadPool(2)
    private val analyzer by lazy { MarketDataAnalyzer() }
    @Volatile private var feed: ExchangeWebSocketFeed? = null
    @Volatile private var configKey: String = ""
    private val scanQueued = AtomicBoolean(false)
    @Volatile private var lastScanAt = 0L
    private var cpuWakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        cpuWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AURUMX:MarketAnalysis")
            .apply { setReferenceCounted(false); acquire() }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "AURUM X continuous analysis", NotificationManager.IMPORTANCE_LOW)
            val signalChannel = NotificationChannel(SIGNAL_CHANNEL_ID, "AURUM X LONG / SHORT alerts", NotificationManager.IMPORTANCE_HIGH)
            manager.createNotificationChannel(channel)
            manager.createNotificationChannel(signalChannel)
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID)
            else @Suppress("DEPRECATION") Notification.Builder(this)
        startForeground(NOTIFICATION_ID, builder.setSmallIcon(R.drawable.ic_stat_aurum)
            .setContentTitle("AURUM X by JAVAD")
            .setContentText("تحلیل پیوسته و دریافت زنده بازار فعال است")
            .setOngoing(true).build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        if (!prefs.getBoolean("continuous_analysis", false)) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (!running) startLoop()
        configureFeed()
        return START_STICKY
    }

    private fun readConfig(): Pair<String, List<String>> {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val exchange = prefs.getString("exchange", "Toobit") ?: "Toobit"
        val json = JSONArray(prefs.getString("selected", "[]") ?: "[]")
        val symbols = (0 until json.length()).map { json.optString(it) }
            .filter { it.matches(Regex("[A-Z0-9]{2,20}USDT")) }.distinct()
        return exchange to symbols
    }

    @Synchronized private fun configureFeed() {
        val (exchange, symbols) = readConfig()
        val newKey = "$exchange|${symbols.joinToString(",")}"
        if (newKey == configKey && feed != null) return
        feed?.close()
        feed = null
        configKey = newKey
        if (exchange !in MarketDataAnalyzer.SUPPORTED_EXCHANGES || symbols.isEmpty()) return
        val newFeed = ExchangeWebSocketFeed(exchange, symbols,
            onCandle = { symbol, timeframe, candle ->
                LiveCandleCache.put(exchange, symbol, timeframe, candle)
                // Cache live candles immediately; decision scans remain on the 60-second cadence.
            },
            onState = { sendStatus(it, running) },
            onDisconnected = {
                if (running) worker.schedule({
                    if (running && configKey == newKey) {
                        feed?.close()
                        feed = null
                        configKey = ""
                        configureFeed()
                    }
                }, 5, TimeUnit.SECONDS)
            })
        feed = newFeed
        newFeed.connect()
    }

    private fun startLoop() {
        running = true
        if (worker.isShutdown) worker = Executors.newScheduledThreadPool(2)
        // Safety refresh in case a venue's WebSocket is temporarily unavailable.
        worker.scheduleWithFixedDelay({
            if (running) {
                configureFeed()
                requestAnalysis("بازبینی دوره‌ای هر ۶۰ ثانیه")
            }
        }, 0, 60, TimeUnit.SECONDS)
    }

    private fun requestAnalysis(reason: String) {
        if (!running || !scanQueued.compareAndSet(false, true)) return
        worker.execute {
            try {
                val now = System.currentTimeMillis()
                if (now - lastScanAt < 5_000L) return@execute
                lastScanAt = now
                runAnalysis(reason)
            } finally { scanQueued.set(false) }
        }
    }

    private fun runAnalysis(reason: String) {
        try {
            val (exchange, symbols) = readConfig()
            if (exchange !in MarketDataAnalyzer.SUPPORTED_EXCHANGES) {
                sendStatus("صرافی ذخیره‌شده معتبر نیست؛ تحلیل متوقف شد تا منبع داده اشتباه استفاده نشود.", true)
                return
            }
            if (symbols.isEmpty()) {
                sendStatus("تحلیل پیوسته روشن است؛ حداقل یک ارز انتخاب کن.", true)
                return
            }
            val reports = mutableListOf<String>()
            val prefs = getSharedPreferences("settings", MODE_PRIVATE)
            val scanPool = Executors.newFixedThreadPool(6)
            try {
                val futures = symbols.map { symbol ->
                    scanPool.submit(Callable {
                        val report = try { analyzer.analyze(symbol, exchange) } catch (_: Exception) { null }
                        symbol to report
                    })
                }
                for (future in futures) {
                    val (symbol, report) = future.get()
                    if (report == null) continue
                    val side = when {
                        report.contains("$symbol  LONG") -> "LONG"
                        report.contains("$symbol  SHORT") -> "SHORT"
                        else -> ""
                    }
                    val previous = prefs.getString("last_confirmed_$symbol", "") ?: ""
                    if (side.isNotEmpty()) {
                        reports.add(report)
                        if (side != previous) notifyConfirmedSignal(symbol, side, report)
                    }
                    prefs.edit().putString("last_confirmed_$symbol", side).apply()
                }
            } finally {
                scanPool.shutdownNow()
            }
            val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val body = if (reports.isEmpty()) "بررسی انجام شد؛ سیگنال تأییدشده‌ای وجود ندارد. اعلان خنثی ارسال نمی‌شود."
                else reports.joinToString("\n\n────────────\n\n")
            sendStatus("● تحلیل پیوسته فعال | منبع: $exchange | بررسی ۶۰ ثانیه‌ای | $time\n\n$body", true)
        } catch (e: Exception) {
            sendStatus("خطای تحلیل: ${e.message ?: e.javaClass.simpleName}", true)
        }
    }


    private fun notifyConfirmedSignal(symbol: String, side: String, report: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val openApp = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(
            this, symbol.hashCode(), openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val summary = report.substringAfter('\n', report).replace('\n', ' ').take(150)
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, SIGNAL_CHANNEL_ID)
        } else @Suppress("DEPRECATION") Notification.Builder(this)
        notification.setSmallIcon(R.drawable.ic_stat_aurum)
            .setContentTitle("AURUM X · $side · $symbol")
            .setContentText(summary)
            .setStyle(Notification.BigTextStyle().bigText(report.take(1500)))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setDefaults(Notification.DEFAULT_ALL)
            .setPriority(Notification.PRIORITY_HIGH)
        manager.notify(symbol.hashCode(), notification.build())
    }

    private fun sendStatus(message: String, isRunning: Boolean) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName)
            .putExtra(EXTRA_STATUS, message).putExtra(EXTRA_RUNNING, isRunning))
    }

    override fun onDestroy() {
        running = false
        feed?.close()
        feed = null
        worker.shutdownNow()
        try { cpuWakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        cpuWakeLock = null
        sendStatus("تحلیل پیوسته متوقف شد.", false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
