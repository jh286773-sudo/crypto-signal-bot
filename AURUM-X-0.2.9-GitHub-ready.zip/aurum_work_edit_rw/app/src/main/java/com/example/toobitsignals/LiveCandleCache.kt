package com.example.toobitsignals

import java.util.concurrent.ConcurrentHashMap

/** Latest in-progress futures candles received from the selected exchange's public WebSocket. */
internal data class LiveCandle(
    val time: Long, val open: Double, val high: Double, val low: Double,
    val close: Double, val volume: Double
)

internal object LiveCandleCache {
    private data class Key(val exchange: String, val symbol: String, val timeframe: String)
    private val values = ConcurrentHashMap<Key, LiveCandle>()

    fun put(exchange: String, symbol: String, timeframe: String, candle: LiveCandle) {
        if (exchange.isBlank() || !symbol.matches(Regex("[A-Z0-9]{2,20}USDT")) ||
            timeframe !in setOf("5m", "15m", "30m")) return
        val duration = when (timeframe) { "5m" -> 300_000L; "15m" -> 900_000L; else -> 1_800_000L }
        val now = System.currentTimeMillis()
        if (candle.time <= 0 || candle.time > now + 60_000L || now - candle.time > duration * 2 ||
            !candle.open.isFinite() || !candle.high.isFinite() || !candle.low.isFinite() ||
            !candle.close.isFinite() || !candle.volume.isFinite() || candle.open <= 0 || candle.close <= 0 ||
            candle.high < maxOf(candle.open, candle.close) || candle.low > minOf(candle.open, candle.close) ||
            candle.low <= 0 || candle.volume < 0) return
        val key = Key(exchange, symbol, timeframe)
        values.compute(key) { _, previous -> if (previous == null || candle.time >= previous.time) candle else previous }
    }

    fun get(exchange: String, symbol: String, timeframe: String): LiveCandle? =
        values[Key(exchange, symbol, timeframe)]?.takeIf {
            val duration = when (timeframe) { "5m" -> 300_000L; "15m" -> 900_000L; else -> 1_800_000L }
            System.currentTimeMillis() - it.time in 0..(duration * 2)
        }

    fun clearExchange(exchange: String) { values.keys.removeAll { it.exchange == exchange } }
}
