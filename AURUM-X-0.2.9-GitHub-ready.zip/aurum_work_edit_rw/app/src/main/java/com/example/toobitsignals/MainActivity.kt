package com.example.toobitsignals

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import org.json.JSONArray
import android.content.BroadcastReceiver
import android.content.IntentFilter

class MainActivity : Activity() {
    private val coins = listOf("BTCUSDT","ETHUSDT","SOLUSDT","XRPUSDT","DOGEUSDT","BNBUSDT","ADAUSDT","LINKUSDT","AVAXUSDT","TRXUSDT","LTCUSDT","BCHUSDT","DOTUSDT","ATOMUSDT","ETCUSDT","NEARUSDT","APTUSDT","OPUSDT","ARBUSDT","SUIUSDT")
    // Each selection is the actual source for every candle request in this scan.
    private val exchanges = listOf("Toobit")
    private val selected = linkedSetOf<String>()
    private val favorites = linkedSetOf<String>()
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var query: EditText
    private lateinit var exchangePicker: Spinner
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var scanButton: Button
    private var scanning = false
    private var scanSymbols: List<String> = emptyList()
    private var scanExchange: String = "Toobit"
    private var statusReceiverRegistered = false
    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: android.content.Intent?) {
            if (intent?.action == KeepAliveService.ACTION_STATUS) {
                val message = intent.getStringExtra(KeepAliveService.EXTRA_STATUS) ?: return
                status.text = message
                scanning = intent.getBooleanExtra(KeepAliveService.EXTRA_RUNNING, scanning)
                scanButton.text = if (scanning) "■  توقف تحلیل پیوسته" else "▶  شروع تحلیل پیوسته"
            }
        }
    }
    private var favoritesOnly = false

    private val bg = Color.rgb(10, 13, 19)
    private val panel = Color.rgb(20, 26, 36)
    private val panelAlt = Color.rgb(27, 35, 47)
    private val gold = Color.rgb(232, 185, 76)
    private val muted = Color.rgb(157, 168, 185)
    private val bright = Color.rgb(241, 244, 250)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun shape(color: Int, stroke: Int = Color.TRANSPARENT, radius: Int = 16): GradientDrawable {
        fun tint(channel: Int, factor: Float) = (channel * factor).toInt().coerceIn(0, 255)
        val top = Color.rgb(tint(Color.red(color), 1.22f), tint(Color.green(color), 1.22f), tint(Color.blue(color), 1.22f))
        val bottom = Color.rgb(tint(Color.red(color), 0.72f), tint(Color.green(color), 0.72f), tint(Color.blue(color), 0.72f))
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, color, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
            setDither(true)
        }
    }
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
        includeFontPadding = false; letterSpacing = if (bold) 0.015f else 0f
        if (bold) setShadowLayer(dp(1).toFloat(), 0f, dp(1).toFloat(), Color.argb(70, 0, 0, 0))
    }
    private fun actionButton(value: String, primary: Boolean = false): Button = Button(this).apply {
        text = value; textSize = 13f; isAllCaps = false; setTextColor(if (primary) Color.rgb(24, 21, 14) else bright)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = if (primary) resources.getDrawable(R.drawable.aurum_button_gold, theme)
            else shape(panelAlt, Color.rgb(76, 82, 91), 14)
        minHeight = dp(50); minimumHeight = dp(50); setPadding(dp(12), 0, dp(12), 0)
        elevation = dp(if (primary) 5 else 1).toFloat()
        stateListAnimator = null
    }
    private fun sectionTitle(value: String): TextView = label(value, 13f, gold, true).apply { gravity = Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL; setPadding(dp(2), dp(18), dp(2), dp(9)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        loadSet("selected", selected); loadSet("favorites", favorites)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 11, 17), Color.rgb(17, 22, 30), Color.rgb(9, 12, 18)))
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(dp(20), dp(19), dp(20), dp(18))
            background = resources.getDrawable(R.drawable.aurum_panel, theme)
            elevation = dp(9).toFloat()
        }
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL }
        brandRow.addView(ImageView(this).apply {
            setImageResource(R.drawable.aurum_bull_4k)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "AURUM X gold bull emblem"
            elevation = dp(8).toFloat()
        }, LinearLayout.LayoutParams(dp(76), dp(76)))
        brandRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(12), 0, 0, 0)
            addView(label("AURUM X", 29f, gold, true).apply { letterSpacing = 0.045f })
            addView(label("PREMIUM MARKET INTELLIGENCE", 8f, muted, true).apply { letterSpacing = 0.13f; setPadding(0, dp(3), 0, 0) })
        })
        hero.addView(brandRow)
        hero.addView(label("BY JAVAD  ·  PROFESSIONAL FUTURES ANALYSIS", 9f, muted, true).apply { letterSpacing = 0.10f; setPadding(0, dp(7), 0, dp(12)) })
        hero.addView(View(this).apply { setBackgroundColor(Color.rgb(115, 91, 48)) }, LinearLayout.LayoutParams(-1, dp(1)))
        hero.addView(label("تحلیل هوشمند بازار فیوچرز", 16f, bright, true).apply { gravity = Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL; setPadding(0, dp(14), 0, dp(4)) })
        hero.addView(label("دریافت داده عمومی بازار  ·  فقط خواندنی", 11f, muted).apply { gravity = Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL; setPadding(0, 0, 0, dp(5)) })
        val liveLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(13), 0, 0) }
        liveLine.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(83, 208, 139)) } }, LinearLayout.LayoutParams(dp(7), dp(7)))
        liveLine.addView(label("  DATA LINK READY  ·  TOOBIT", 9f, Color.rgb(132, 207, 158), true))
        hero.addView(liveLine)
        root.addView(hero, LinearLayout.LayoutParams(-1, -2))

        root.addView(sectionTitle("منبع داده و تحلیل"))
        val exchangeCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(dp(13), dp(8), dp(13), dp(8)); background = resources.getDrawable(R.drawable.aurum_panel, theme); elevation = dp(3).toFloat() }
        exchangePicker = Spinner(this).apply {
            adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, exchanges) {
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                    val v = super.getView(position, convertView, parent) as TextView
                    v.setTextColor(bright); v.textSize = 14f; v.typeface = Typeface.DEFAULT_BOLD; v.setPadding(dp(5), dp(8), dp(5), dp(8)); return v
                }
                override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                    val v = super.getDropDownView(position, convertView, parent) as TextView
                    v.setTextColor(bright); v.setBackgroundColor(panel); v.textSize = 14f; v.setPadding(dp(14), dp(12), dp(14), dp(12)); return v
                }
            }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            val saved = prefs.getString("exchange", "Toobit") ?: "Toobit"
            setSelection(exchanges.indexOf(saved).coerceAtLeast(0))
            background = null
            onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { scanExchange = exchanges[position]; prefs.edit().putString("exchange", exchanges[position]).apply(); if (scanning) startContinuousAnalysis() }
            }
        }
        exchangeCard.addView(exchangePicker)
        root.addView(exchangeCard, LinearLayout.LayoutParams(-1, -2))

        root.addView(sectionTitle("جستجو و انتخاب ارز"))
        query = EditText(this).apply {
            hint = "جست‌وجوی نماد، مثل BTC یا ETH"; textDirection = View.TEXT_DIRECTION_RTL; textAlignment = View.TEXT_ALIGNMENT_VIEW_END; setHintTextColor(Color.rgb(113, 125, 143)); setTextColor(bright)
            textSize = 14f; singleLine = true; setPadding(dp(15), 0, dp(15), 0)
            background = shape(Color.rgb(19, 25, 34), Color.rgb(111, 91, 54), 15); minimumHeight = dp(52); elevation = dp(2).toFloat()
        }
        root.addView(query, LinearLayout.LayoutParams(-1, dp(50)))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(0, dp(9), 0, 0) }
        val allBtn = actionButton("همه ارزها", true); val favBtn = actionButton("علاقه‌مندی‌ها  ☆")
        buttons.addView(allBtn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        buttons.addView(favBtn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) })
        root.addView(buttons)

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(0, dp(8), 0, 0) }
        val scanBtn = actionButton("▶  شروع تحلیل", true); val clearBtn = actionButton("پاک‌کردن انتخاب")
        actionRow.addView(scanBtn, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(5) })
        actionRow.addView(clearBtn, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(5) })
        root.addView(actionRow)

        status = label("صرافی و ارزها را انتخاب کن.", 13f, bright).apply {
            setPadding(dp(14), dp(13), dp(14), dp(13)); setLineSpacing(dp(4).toFloat(), 1f)
            background = resources.getDrawable(R.drawable.aurum_panel, theme); gravity = Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL; elevation = dp(3).toFloat()
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(10) })
        val listScroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        listScroll.addView(listBox)
        root.addView(listScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4102)
        }

        allBtn.setOnClickListener { favoritesOnly = false; renderList() }
        favBtn.setOnClickListener { favoritesOnly = true; renderList() }
        clearBtn.setOnClickListener { selected.clear(); scanSymbols = emptyList(); saveSet("selected", selected); renderList() }
        scanButton = scanBtn
        scanBtn.setOnClickListener { scanSelected() }
        query.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderList() }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderList()
        scanExchange = exchangePicker.selectedItem.toString()
        scanSymbols = selected.toList()
        val filter = IntentFilter(KeepAliveService.ACTION_STATUS)
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(statusReceiver, filter)
        statusReceiverRegistered = true
        if (prefs.getBoolean("continuous_analysis", false)) startContinuousAnalysis()
    }

    private fun loadSet(key:String, into:MutableSet<String>) { try { val a=JSONArray(prefs.getString(key,"[]") ?: "[]"); for(i in 0 until a.length()) into.add(a.getString(i)) } catch(_:Exception){} }
    private fun saveSet(key:String, values:Set<String>) { val a=JSONArray(); values.forEach{a.put(it)}; prefs.edit().putString(key,a.toString()).apply() }
    private fun renderList() {
        listBox.removeAllViews()
        val q = query.text.toString().trim().uppercase()
        val source = if (favoritesOnly) coins.filter { favorites.contains(it) } else coins
        val filtered = source.filter { it.contains(q) }
        // Keep selected currencies at the top, newest selection first.
        val selectedFirst = selected.toList().asReversed().filter { filtered.contains(it) }
        val shown = selectedFirst + filtered.filterNot { selected.contains(it) }
        listBox.addView(sectionTitle(if (favoritesOnly) "ارزهای موردعلاقه  ·  ${shown.size} نماد" else "فهرست ارزها  ·  ${shown.size} نماد  ·  انتخاب‌شده: ${selected.size}"))
        if (shown.isEmpty()) {
            listBox.addView(label("موردی پیدا نشد.", 13f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(25), 0, dp(25)) })
        }
        shown.forEach { symbol ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(4), dp(8), dp(4))
                background = if (selected.contains(symbol)) shape(Color.rgb(39, 34, 23), Color.rgb(191, 145, 54), 15)
                    else shape(Color.rgb(20, 26, 36), Color.rgb(54, 63, 77), 15)
                elevation = dp(if (selected.contains(symbol)) 4 else 1).toFloat()
            }
            val check = CheckBox(this).apply {
                text = symbol; textSize = 14f; typeface = Typeface.create("sans-serif", Typeface.BOLD); setTextColor(bright)
                buttonTintList = ColorStateList.valueOf(if (selected.contains(symbol)) gold else muted)
                isChecked = selected.contains(symbol)
                setOnCheckedChangeListener { _, v ->
                    if (v) {
                        selected.remove(symbol)
                        selected.add(symbol) // newest selection moves to the top
                    } else {
                        selected.remove(symbol)
                    }
                    saveSet("selected", selected)
                    scanSymbols = selected.toList()
                    renderList() // refresh checked-circle fill, row styling, count and ordering
                }
            }
            row.addView(check, LinearLayout.LayoutParams(0, dp(48), 1f))
            row.setOnClickListener {
                check.isChecked = !check.isChecked
            }
            val star = TextView(this).apply {
                text = if (favorites.contains(symbol)) "★" else "☆"; textSize = 23f
                setTextColor(if (favorites.contains(symbol)) gold else muted); gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(8), 0); minWidth = dp(42)
                setOnClickListener {
                    if (favorites.contains(symbol)) favorites.remove(symbol) else favorites.add(symbol)
                    saveSet("favorites", favorites); renderList()
                }
            }
            row.addView(star, LinearLayout.LayoutParams(dp(48), dp(48)))
            listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
    }

    private fun scanSelected() {
        if (scanning) {
            stopContinuousAnalysis()
            return
        }
        scanSymbols = selected.toList()
        scanExchange = exchangePicker.selectedItem.toString()
        if (scanSymbols.isEmpty()) { status.text = "ابتدا حداقل یک ارز را انتخاب کن."; return }
        startContinuousAnalysis()
    }

    private fun startContinuousAnalysis() {
        scanSymbols = selected.toList().ifEmpty { scanSymbols }
        scanExchange = exchangePicker.selectedItem?.toString() ?: scanExchange
        if (scanSymbols.isEmpty()) { status.text = "برای شروع، حداقل یک ارز انتخاب کن."; return }
        prefs.edit().putString("selected", JSONArray(scanSymbols).toString())
            .putString("exchange", scanExchange).putBoolean("continuous_analysis", true).apply()
        scanning = true
        scanButton.text = "■  توقف تحلیل پیوسته"
        status.text = "تحلیل پیوسته در سرویس پس‌زمینه فعال شد؛ منبع: $scanExchange"
        val intent = android.content.Intent(this, KeepAliveService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun stopContinuousAnalysis() {
        scanning = false
        prefs.edit().putBoolean("continuous_analysis", false).apply()
        stopService(android.content.Intent(this, KeepAliveService::class.java))
        scanButton.text = "▶  شروع تحلیل پیوسته"
        status.text = "تحلیل پیوسته متوقف شد."
    }

    override fun onDestroy() {
        if (statusReceiverRegistered) {
            try { unregisterReceiver(statusReceiver) } catch (_: Exception) { }
            statusReceiverRegistered = false
        }
        super.onDestroy()
    }
}
