plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.toobitsignals"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.toobitsignals"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "0.2.9"
    }
}


dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
