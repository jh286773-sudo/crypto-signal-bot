# AURUM X visual upgrade — 0.2.6

## Applied in source
- Replaced the angular letter-like launcher mark with a custom scalable bull-head vector mark.
- Reworked the main brand panel with layered charcoal/gold gradients, elevation, spacing and a live data-link indicator.
- Upgraded primary buttons to a metallic gold gradient with subtle elevation.
- Applied a consistent premium dark/gold panel treatment to the exchange selector and status area.
- Improved market-list row contrast and selected-state treatment; all artwork is vector-based and scales cleanly on high-density displays.
- Bumped Android app version to 0.2.6 (versionCode 6).

## Important technical note
Android UI is rendered at the device's native density and resolution. Vector artwork is resolution-independent; this is more appropriate for crisp UI on different phones than forcing a 4K bitmap onto a mobile screen. The source archive does not contain a full set of 4K photographic/3D assets or multiple app screens. This revision upgrades the actual screen and launcher art present in the supplied source; it does not claim a verified 4K APK build.
