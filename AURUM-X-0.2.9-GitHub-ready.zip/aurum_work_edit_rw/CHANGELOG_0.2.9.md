# AURUM X 0.2.9 — maintenance update

- Replaced `SignalEngine.kt` with the validated three-timeframe consensus engine supplied for this project.
- Normalized exchange candle timestamps (seconds, milliseconds, microseconds and nanoseconds) to epoch milliseconds.
- Hardened the live candle cache against invalid symbols/timeframes, malformed OHLCV values, stale/future candles and out-of-order updates.
- Hardened Toobit WebSocket parsing for array and single-object candle payloads, with strict symbol/timeframe filtering.
- Prevented a stale WebSocket candle from overwriting newer REST candle history.
- Kept signal notifications restricted to confirmed LONG/SHORT signals; NO_SIGNAL remains status-only.

Validation performed in this workspace: six Python reference-engine tests passed; Kotlin `SignalEngine.kt` and `LiveCandleCache.kt` compile independently. Full Android/Gradle build and live Toobit/device integration tests were not available in this workspace.

### WebSocket lifecycle hardening (2026-11-20)
- Cancel the Toobit heartbeat task when its socket closes or fails, and replace any prior task when a connection opens.
- Ignore heartbeat work for sockets that are no longer the active connection.
- Guard disconnect notification so a failure/close callback pair cannot trigger duplicate reconnect scheduling.
- Validation performed: standalone Kotlin compile for SignalEngine and LiveCandleCache; six Python reference-engine tests; source-level WebSocket lifecycle checks.
- Full Android Gradle build and device/live-exchange tests remain pending because this workspace has no Android SDK or installed Gradle distribution.
