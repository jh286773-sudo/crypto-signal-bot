# AURUM X exchange support — 0.2.4

The exchange picker remains single-select. The selected venue is the only source passed to the analysis engine for 5m, 15m and 30m. There is no silent fallback to Toobit.

## Supported USDT perpetual market-data sources

| Exchange | REST history | Public WebSocket | Live candle enters analysis cache |
|---|---:|---:|---:|
| Toobit | Yes | Existing adapter | Existing stream parser path |
| Binance Futures | Yes | Combined kline stream | Yes |
| Bybit | Yes | Public linear kline | Yes |
| OKX | Yes | Public swap candle | Yes |
| Bitget | Yes | Public USDT-Futures candle | Yes |
| Gate.io | Yes | USDT futures candlestick | Yes |
| CoinEx | Yes | Perpetual kline | Yes |
| MEXC Futures | Yes | `push.kline` subscription | Yes |
| BingX | Yes | Swap market kline; GZIP frames decompressed | Yes |
| KuCoin Futures | Yes | Public token bootstrap + futures candle topic | Yes |
| Phemex | Yes | `kline_p.subscribe` | Yes |

REST provides historical candles; each valid, recent WebSocket candle replaces the matching in-progress candle in the selected exchange's analysis series. A REST safety refresh remains enabled for history recovery and socket outages. WebSocket heartbeats are handled for MEXC, BingX and KuCoin; reconnect is managed by the foreground service.

## API implementation details

- MEXC uses the contract kline endpoint and `wss://contract.mexc.com/edge`.
- BingX uses USDT-M swap klines, the swap-market WebSocket and GZIP decompression; the REST request includes the documented source header.
- KuCoin obtains a public Futures bullet token before connecting and subscribes to `/contractMarket/limitCandle` topics. The BTC contract maps to `XBTUSDTM`.
- Phemex uses the public contract kline endpoint and the `kline_p` WebSocket methods. Its response parser accepts the documented `data.rows` shape.

LBank is not listed as an analysis source: a public perpetual-futures OHLCV endpoint has not been established in the official API documentation, so spot data is not substituted.

## Verification status

The modified WebSocket/cache/analyzer Kotlin files pass a standalone Kotlin syntax/type check against local API stubs. The four Python reference-engine tests pass. Live REST/WebSocket handshakes could not be run because this environment has no outbound DNS/network access. An Android APK build also could not be run because the Android SDK, Gradle executable, wrapper JAR and dependency cache are unavailable. The source archive is not an installable APK until built and live-tested in Android Studio or CI.
